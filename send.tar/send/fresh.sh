#!/bin/bash
#echo -n 'text2' >> /var/log/cnps/DECLARATION_COTISATION_GLOBAL.log
logfile=$1
sed -i '2 s/./text2&/' $logfile
sed -i 's/text2//' $logfile
sed -i '/^$/d' $logfile
